import java.security.*;

public class ConcreteIdentity extends Identity {
  public ConcreteIdentity(String name) { super(name); }
}